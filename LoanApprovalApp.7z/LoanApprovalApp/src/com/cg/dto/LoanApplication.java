package com.cg.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Columns;

@Entity
@Table(name="LAPSLoanApplication")
public class LoanApplication {

	public LoanApplication() {}
		// TODO Auto-generated constructor stub
	    @ID
	    @Column(name="application_id")
	    @NotNull(message="Mobile Id cannot be empty")
		int applicationID;
	    @Column(name="application_date")
		Date applicationDate;
	    
	    @Column(name="loan_program")
		String loanProgram;
	    
	    @Column(name="AmountofLoan")
		double amountOfLoan;
	    
	    @Column(name="AddressofProperty")
		String addressOfProperty;
	    
	    @Column(name="AnnualFamilySalary")
		double annualFamilyIncome;
	    
	    @Column(name="DocumentProofAvailable")
		String documentProofAvail;
	    
	    @Column(name="GuranteeCover")
		String guranteeCover;
	    
	    @Column(name="MarketValueOfGuranteeCover")
		double marketValOfGuranteeCover;
	    
	    @Column(name="Status")
		String Status;
	    
	    @Column(name="DateOfInterview")
		Date dateOFInterview;
		public LoanApplication(int applicationId, Date applicationDate,
				String loanProgram, double amountOfLoan,
				String addressOfProperty, double annualFamilyIncome,
				String documentProofAvail, String guranteeCover,
				double marketValOfGuranteeCover, String status,
				Date dateOFInterview) {
			super();
			this.applicationID = applicationId;
			this.applicationDate = applicationDate;
			this.loanProgram = loanProgram;
			this.amountOfLoan = amountOfLoan;
			this.addressOfProperty = addressOfProperty;
			this.annualFamilyIncome = annualFamilyIncome;
			this.documentProofAvail = documentProofAvail;
			this.guranteeCover = guranteeCover;
			this.marketValOfGuranteeCover = marketValOfGuranteeCover;
			Status = status;
			this.dateOFInterview = dateOFInterview;
		}
		public int getApplicationId() {
			return applicationID;
		}
		public void setApplicationId(int applicationId) {
			this.applicationID = applicationId;
		}
		public Date getApplicationDate() {
			return applicationDate;
		}
		public void setApplicationDate(Date applicationDate) {
			this.applicationDate = applicationDate;
		}
		public String getLoanProgram() {
			return loanProgram;
		}
		public void setLoanProgram(String loanProgram) {
			this.loanProgram = loanProgram;
		}
		public double getAmountOfLoan() {
			return amountOfLoan;
		}
		public void setAmountOfLoan(double amountOfLoan) {
			this.amountOfLoan = amountOfLoan;
		}
		public String getAddressOfProperty() {
			return addressOfProperty;
		}
		public void setAddressOfProperty(String addressOfProperty) {
			this.addressOfProperty = addressOfProperty;
		}
		public double getAnnualFamilyIncome() {
			return annualFamilyIncome;
		}
		public void setAnnualFamilyIncome(double annualFamilyIncome) {
			this.annualFamilyIncome = annualFamilyIncome;
		}
		public String getDocumentProofAvail() {
			return documentProofAvail;
		}
		public void setDocumentProofAvail(String documentProofAvail) {
			this.documentProofAvail = documentProofAvail;
		}
		public String getGuranteeCover() {
			return guranteeCover;
		}
		public void setGuranteeCover(String guranteeCover) {
			this.guranteeCover = guranteeCover;
		}
		public double getMarketValOfGuranteeCover() {
			return marketValOfGuranteeCover;
		}
		public void setMarketValOfGuranteeCover(double marketValOfGuranteeCover) {
			this.marketValOfGuranteeCover = marketValOfGuranteeCover;
		}
		public String getStatus() {
			return Status;
		}
		public void setStatus(String status) {
			Status = status;
		}
		public Date getDateOFInterview() {
			return dateOFInterview;
		}
		public void setDateOFInterview(Date dateOFInterview) {
			this.dateOFInterview = dateOFInterview;
		}
		@Override
		public String toString() {
			return "LoanApplication [applicationId=" + applicationID
					+ ", applicationDate=" + applicationDate + ", loanProgram="
					+ loanProgram + ", amountOfLoan=" + amountOfLoan
					+ ", addressOfProperty=" + addressOfProperty
					+ ", annualFamilyIncome=" + annualFamilyIncome
					+ ", documentProofAvail=" + documentProofAvail
					+ ", guranteeCover=" + guranteeCover
					+ ", marketValOfGuranteeCover=" + marketValOfGuranteeCover
					+ ", Status=" + Status + ", dateOFInterview="
					+ dateOFInterview + "]";
		}
		
		
		
		
	

}
