package com.cg.dto;

import java.util.Date;
@Entity
@Table(name="LAPSCustomerDetails")
public class CustomerDetails {

	public CustomerDetails() {
		// TODO Auto-generated constructor stub
	}
	    @ID
	    @Column(name="application_id")
		int applicationID;
	    
	    @Column(name="Applicant_name")
		String applicantName;
	    
	    @Column(name="date_of_birth")
		Date dateOfBirth;
	    
	    @Column(name="marital_status")
		String maritalStatus;
	    
	    @Column(name="phone_number")
		String phoneNumber;
	    
	    @Column(name="mobile_number")
		String mobileNumber;
	    
	    @Column(name="CountofDependents")
		int countOfDependents;
	    
	    @Column(name="email_id")
        String email;
		@Override
		public String toString() {
			return "CustomerDetails [applicationID=" + applicationID
					+ ", applicantName=" + applicantName + ", maritalStatus="
					+ maritalStatus + ", phoneNumber=" + phoneNumber
					+ ", mobileNumber=" + mobileNumber + ", countOfDependents="
					+ countOfDependents + ", email=" + email + "]";
		}
		public CustomerDetails(int applicationID, String applicantName,
				Date dateOfBirth, String maritalStatus, String phoneNumber,
				String mobileNumber, int countOfDependents, String email) {
			super();
			this.applicationID = applicationID;
			this.applicantName = applicantName;
			this.dateOfBirth = dateOfBirth;
			this.maritalStatus = maritalStatus;
			this.phoneNumber = phoneNumber;
			this.mobileNumber = mobileNumber;
			this.countOfDependents = countOfDependents;
			this.email = email;
		}		
	
        
        

}
