package com.cg.dto;

import org.hibernate.annotations.Entity;
import org.hibernate.annotations.Table;


@Entity
@Table(name="Users")
public class Users {

	public Users() {
		// TODO Auto-generated constructor stub
	}
	
	 @Column(name="login_id")
	int loginID;
	 
	 @Column(name="password")
	String password;
	 
	 @Column(name="role")
	String role;
	@Override
	public String toString() {
		return "Users [loginId=" + loginID + ", password=" + password
				+ ", role=" + role + "]";
	}
	public Users(int loginId, String password, String role) {
		super();
		this.loginID = loginId;
		this.password = password;
		this.role = role;
	}
	public int getLoginId() {
		return loginID;
	}
	public void setLoginId(int loginId) {
		this.loginID = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	

}
